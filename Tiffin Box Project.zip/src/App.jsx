import 'react-toastify/dist/ReactToastify.css';

import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Home from './components/Home'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Master from './layout/Master'
import About from './components/About'
import Service from './components/Service'
import Menu from './components/Menu'
import Contact from './components/Contact'
import Team from './components/team'
import Testimonial from './components/Testimonial'
import Login from './components/Login'
import Register from './components/Register'
import Adminmaster from './layout/Adminmaster'
import Adminhome from './components/Adminhome'
import Addcategory from './components/Addcategory'
import Managecategory from './components/Managecategory'
import Updatecategory from './components/Updatecategory'
import Logout from './components/Logout'
import AddMenuItem from './components/admin/AddMenuItem'
import ManageMenu from './components/admin/ManageMenu'
import UpdateMenu from './components/admin/UpdateMenu'
import ManageUser from './components/admin/ManageUser'
import MenuByCategory from './components/MenuByCategory'
import DailyEntry from './components/admin/DailyEntry'
import SendBooking from './components/SendBooking'
import ManageBookings from './components/admin/ManageBookings'
import ViewDailyEntry from './components/admin/ViewDailyEntry'
import UserDailyEntry from './components/UserDailyEntry'
import ViewBill from './components/ViewBill'
import { ToastContainer } from 'react-toastify'
// annpan

function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Master />}>
            <Route path='/' element={<Home />} />
            <Route path='/about' element={<About />} />
            <Route path='/service' element={<Service />} />
            <Route path='/menu' element={<Service />} />
            <Route path='/menuItem/:categoryName' element={<MenuByCategory></MenuByCategory>} />
            <Route path='/contact' element={<Contact />} />
            <Route path='/register' element={<Register />} />
            <Route path='/team' element={<Team />} />
            <Route path='/testimonial' element={<Testimonial />} />
            <Route path='/login' element={<Login />} />
            <Route path='/sendbooking' element={<SendBooking></SendBooking>} />
            <Route path='/dailyentry' element={<UserDailyEntry></UserDailyEntry>} />
            <Route path='/viewbill' element={<ViewBill></ViewBill>} />
            <Route path='/logout' element={<Logout></Logout>} />
          </Route>

          <Route path='/admin' element={<Adminmaster />}>
            <Route path='/admin' element={<Adminhome />} />
            <Route path='/admin/addcategory' element={<Addcategory />} />
            <Route path='/admin/managecategory' element={<Managecategory />} />
            <Route path='/admin/updatecategory/:id' element={<Updatecategory />} />
            <Route path='/admin/addmenu' element={<AddMenuItem></AddMenuItem>} />
            <Route path='/admin/managemenu' element={<ManageMenu></ManageMenu>} />
            <Route path='/admin/updatemenu/:id' element={<UpdateMenu></UpdateMenu>} />
            <Route path='/admin/manageuser' element={<ManageUser></ManageUser>} />
            <Route path='/admin/adddailyentry' element={<DailyEntry></DailyEntry>} />
            <Route path='/admin/managebookings' element={<ManageBookings></ManageBookings>} />
            <Route path='/admin/viewdailyentry' element={<ViewDailyEntry></ViewDailyEntry>} />

          </Route>
        </Routes>
      </BrowserRouter>

     <ToastContainer
  position="top-center"
  autoClose={3000}
  containerStyle={{ zIndex: 999999, position: 'fixed', top: '20px', left: 0, right: 0 }}
  toastStyle={{ pointerEvents: 'auto' }}
/>
    </>
  )
}

export default App
