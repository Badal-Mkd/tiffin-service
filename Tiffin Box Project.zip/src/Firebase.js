// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyA8tRu6JbG0egxLF8vlxbjV3o2rumCFxPg",
//   authDomain: "project-annpan.firebaseapp.com",
//   projectId: "project-annpan",
//   storageBucket: "project-annpan.firebasestorage.app",
//   messagingSenderId: "158101979743",
//   appId: "1:158101979743:web:3df5a7bc3bf7640f9bd1ea",
//   measurementId: "G-535W75KG1T"
// };

const firebaseConfig = {
  apiKey: "AIzaSyC4AlQyzCpdsWmtpnv0RUXOVazNfiUDKIA",
  authDomain: "fir-revision-668b9.firebaseapp.com",
  projectId: "fir-revision-668b9",
  storageBucket: "fir-revision-668b9.firebasestorage.app",
  messagingSenderId: "936640427216",
  appId: "1:936640427216:web:bcf2b16fd9e7d5ea941ad5"
};


// Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "your api key here",
//   authDomain: "your authDomain",
//   projectId: "your projectId",
//   storageBucket: "your storageBucket",
//   messagingSenderId: "your messagingSenderId",
//   appId: "your appId"
// };


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth=getAuth(app);
export const db=getFirestore(app);
