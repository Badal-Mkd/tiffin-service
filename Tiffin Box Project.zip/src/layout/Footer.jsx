import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <>
        {/* Footer Start */}
        <div
          className="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn"
          data-wow-delay="0.1s"
        >
          <div className="container py-5">
            <div className="row g-5 justify-content-center">
              <div className="col-lg-3 col-md-6">
                <h4 className="section-title ff-secondary text-start text-primary fw-normal mb-4">
                  Annpan
                </h4>
                <Link to={"/"} className="btn btn-link" href="">
                  Home
                </Link>
                <Link to={"/about"} className="btn btn-link" href="">
                 About
                </Link>
                <Link to={"/menu"} className="btn btn-link" href="">
                  Menu
                </Link>
                <Link to={"/team"} className="btn btn-link" href="">
                  Our Team
                </Link>
                <Link to={"/contact"} className="btn btn-link" href="">
                  Contact
                </Link>
              </div>
              <div className="col-lg-3 col-md-6">
                <h4 className="section-title ff-secondary text-start text-primary fw-normal mb-4">
                  Contact
                </h4>
                <p className="mb-2">
                  <i className="fa fa-map-marker-alt me-3" />
                  123 Street, Jalandhar
                </p>
                <p className="mb-2">
                  <i className="fa fa-phone-alt me-3" />
                  +91 987654321
                </p>
                <p className="mb-2">
                  <i className="fa fa-envelope me-3" />
                  annpan@gmail.com
                </p>
                <div className="d-flex pt-2">
                  <a className="btn btn-outline-light btn-social" href="">
                    <i className="fab fa-twitter" />
                  </a>
                  <a className="btn btn-outline-light btn-social" href="">
                    <i className="fab fa-facebook-f" />
                  </a>
                  <a className="btn btn-outline-light btn-social" href="">
                    <i className="fab fa-youtube" />
                  </a>
                  <a className="btn btn-outline-light btn-social" href="">
                    <i className="fab fa-linkedin-in" />
                  </a>
                </div>
              </div>
              <div className="col-lg-3 col-md-6">
                <h4 className="section-title ff-secondary text-start text-primary fw-normal mb-4">
                  Opening
                </h4>
                <h5 className="text-light fw-normal">Monday - Saturday</h5>
                <p>09AM - 09PM</p>
                <h5 className="text-light fw-normal">Sunday</h5>
                <p>10AM - 08PM</p>
              </div>
              
            </div>
          </div>
        
        </div>
        {/* Footer End */}
        {/* Back to Top */}

        <a href="#" className="btn  btn-primary border-3 btn-lg-square back-to-top border-primary rounded-circle ">
          <i className="bi bi-arrow-up" />
        </a>
      </>

    </>
  )
}