import { Outlet, useNavigate } from "react-router-dom";
import Adminheader from "./Adminheader";
import Adminfooter from "./Adminfooter";
import { toast } from "react-toastify";
import { useEffect } from "react";

export default function Adminmaster(){
    const navigate = useNavigate();

    useEffect(() => {
        
        if (sessionStorage.userType !== "1" || sessionStorage.email !== "admin@gmail.com") {
            toast.error("Unauthorized Access!", { position: "top-center" });
            setTimeout(() => {
                navigate("/login");
            }, 100); // small delay so toast can render
        }
    }, [navigate]);

    return(
        <>
            <Adminheader/>
            <Outlet/>
            {/* <Adminfooter/> */}
        </>
    )
}
