import { Link } from "react-router-dom";

export default function Header() {
  return (
    <>
      <>
        {/* Navbar & Hero Start */}
        <div className="container-fluid  position-relative p-0">
          <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
            <a href="" className="navbar-brand p-0">
              <h1 className="text-primary m-0">
                <i className="fa fa-utensils me-3" />
                Annpan
              </h1>
              {/* <img src="img/logo.png" alt="Logo"> */}
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarCollapse"
            >
              <span className="fa fa-bars" />
            </button>
            <div className="collapse navbar-collapse" id="navbarCollapse">
              <div className="navbar-nav ms-auto py-0 pe-4">
                <Link to="/" className="nav-item nav-link">
                  Home
                </Link>
                <Link to="/about" className="nav-item nav-link active">
                  About
                </Link>
                {/* <Link to="/service" className="nav-item nav-link">
            Service
          </Link> */}
                <Link to="/menu" className="nav-item nav-link">
                  Menu
                </Link>


                <Link to="/team" className="nav-item nav-link">
                  Our Team
                </Link>
                
                <Link to="/contact" className="nav-item nav-link">
                  Contact
                </Link>
                {sessionStorage.getItem("email") ? <div className="nav-item dropdown">
                  <a
                    href="#"
                    className="nav-link dropdown-toggle"
                    data-bs-toggle="dropdown"
                  >
                    Pages
                  </a>
                  <div className="dropdown-menu m-0">

                    <Link to="/dailyentry" className="dropdown-item">
                      Deliveries
                    </Link>
                    <Link to="/viewbill" className="dropdown-item">
                      Bill
                    </Link>
                  </div>
                </div> : ""}

                 <Link to="/sendbooking" className="nav-item nav-link">
                  Send Booking
                </Link>
              </div>



              {sessionStorage.getItem("email") ?

                <Link to="/logout" className="btn btn-primary py-2 px-4">
                  Logout
                </Link>
                :
                <Link to="/login" className="btn btn-primary py-2 px-4">
                  Login
                </Link>}

            </div>
          </nav>
        </div>
        {/* <div className="container-fluid py-5 bg-dark hero-header ">
  </div> */}
        {/* Navbar & Hero End */}
      </>


    </>
  )
}