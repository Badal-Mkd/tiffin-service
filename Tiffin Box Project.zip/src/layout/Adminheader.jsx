import { Link } from "react-router-dom";

export default function Adminheader() {
  return (
    <>
      <>
        {/* Navbar & Hero Start */}
        <div className="container-fluid  position-relative p-0">
          <nav className="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
            <a href="" className="navbar-brand p-0">
              <h1 className="text-primary m-0">
                <i className="fa fa-utensils me-3" />
                Annpan
              </h1>
              {/* <img src="img/logo.png" alt="Logo"> */}
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarCollapse"
            >
              <span className="fa fa-bars" />
            </button>
            <div className="collapse navbar-collapse" id="navbarCollapse">
              <div className="navbar-nav ms-auto py-0 pe-4">
                <Link to="/admin" className="nav-item nav-link">
                  Home
                </Link>


                <div className="nav-item dropdown">
                  <a
                    href="#"
                    className="nav-link dropdown-toggle"
                    data-bs-toggle="dropdown"
                  >
                    Categories
                  </a>
                  <div className="dropdown-menu m-0">
                    <Link to="/admin/addcategory" className="dropdown-item">
                      Add
                    </Link>
                    <Link to="/admin/managecategory" className="dropdown-item">
                      Manage
                    </Link>

                  </div>
                </div>


                
                <div className="nav-item dropdown">
                  <a
                    href="#"
                    className="nav-link dropdown-toggle"
                    data-bs-toggle="dropdown"
                  >
                    Menu Items
                  </a>
                  <div className="dropdown-menu m-0">
                    <Link to="/admin/addmenu" className="dropdown-item">
                      Add
                    </Link>
                    <Link to="/admin/managemenu" className="dropdown-item">
                      Manage
                    </Link>

                  </div>
                </div>



                {/* <Link className="nav-item nav-link">
                  View Boooking
                </Link> */}
                <div className="nav-item dropdown">
                  <a
                    href="#"
                    className="nav-link dropdown-toggle"
                    data-bs-toggle="dropdown"
                  >
                    Daily Entries
                  </a>
                  <div className="dropdown-menu m-0">
                    <Link to={"/admin/adddailyentry"} className="dropdown-item">
                      Add
                    </Link>
                    <Link to={"/admin/viewdailyentry"} className="dropdown-item">
                      View
                    </Link>

                  </div>

                </div>

                <Link to={"/admin/managebookings"} className="nav-item nav-link">
                  Bookings
                </Link>

                <Link to={"/admin/manageuser"} className="nav-item nav-link">
                  Users
                </Link>
                
                <Link to={"/logout"} className="nav-item nav-link">
                  Logout
                </Link>

              </div>

            </div>
          </nav>
        </div>
        {/* <div className="container-fluid py-5 bg-dark hero-header ">
  </div> */}
        {/* Navbar & Hero End */}
      </>


    </>
  )
}