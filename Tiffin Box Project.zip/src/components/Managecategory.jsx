import { collection, deleteDoc, doc, onSnapshot, query, where } from "firebase/firestore"
import { db } from "../Firebase"
import { useEffect, useState } from "react"
import { toast, ToastContainer } from "react-toastify"
import { Link } from "react-router-dom"

export default function Managecategory() {

    const [catedata, setcatedata] = useState([])
    useEffect(() => {

        const fatchData = () => {
            onSnapshot(collection(db, "category"), (CategoryData) => {
                // console.log("data",CategoryData.docs[0].data());
                setcatedata(
                    CategoryData.docs.map((el) => {
                        // return(el.data)
                        return { id: el.id, ...el.data() }


                    })
                )

            })
        }

        fatchData()

    }, [])


    const deleteCate = async (id) => {
        // console.log(id);
        await deleteDoc(doc(db, "category", id)).then(() => {
            toast.success("Category Deleted Successfully!!")
        }).catch(() => {
            toast.error("Error")
        })

    }

    return (
        <>
            <ToastContainer />
            {/* <p>{catedata[0].id}</p> */}
            <div className="container-fluid py-5 bg-dark hero-header mb-5">
                <div className="container text-center my-5 pt-5 pb-4">
                    <h1 className="display-3 text-white mb-3 animated slideInDown">
                        Manage Category
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb justify-content-center text-uppercase">
                            <li className="breadcrumb-item">
                                <a href="#">home</a>
                            </li>
                            <li className="breadcrumb-item">
                                <a href="#">Pages</a>
                            </li>
                            <li className="breadcrumb-item text-white active" aria-current="page">
                                managecategory
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div className="container-fluid py-5">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="offset-md-1 col-md-10">
                            <table className="table table-bordered ">
                                <thead>

                                    <tr>
                                        <th className="">Sr.no</th>
                                        <th className="">Name</th>
                                        <th className="ps-4">Image</th>
                                        {/*<th className="ps-4">Type</th>
                                    <th className="p-2">price</th>
                                    <th className="p-2">Description</th> */}
                                        <th className="p-2">Update</th>
                                        <th className="p-2">Deleßte</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {
                                        catedata.map((el, index) => {
                                            console.log("All Category", el)
                                            return <tr key={index}>
                                                <td>{index + 1}</td>
                                                <td>{el.name}</td>
                                                <td><img src={el.image} alt="" width={"100px"} /></td>
                                                {/* <td>{el.type}</td>
                                            <td>{el.price}</td>

                                            <td>{el.description}</td> */}
                                                <td><Link to={"/admin/updatecategory/" + el.id} className="btn bg-primary text-white rounded-pill">Update</Link></td>

                                                <td><button type="button" className="btn bg-danger text-white rounded-pill" onClick={() => {
                                                    deleteCate(el.id)
                                                }} >delete</button></td>
                                            </tr>
                                        })
                                    }


                                    {catedata.length === 0 && (
                                        <tr>
                                            <td colSpan="8" className="text-center">No data available</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>


                        </div>
                    </div>
                    <div className="row align-items-center">

                    </div>
                </div>
            </div>

        </>
    )
}