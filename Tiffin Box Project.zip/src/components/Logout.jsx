import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { toast } from "react-toastify"

export default function Logout() {
    var nav = useNavigate()

    useEffect(() => {
        sessionStorage.clear()
        localStorage.clear()
        toast.success("Logout successfully!")
        setTimeout(() => {
            // nav("/")
              nav("/login", { state: { msg: "Logout successfully!" } });
            window.location.reload()
        }, 300);
    }, [])

    return null
}
