import { useEffect, useState } from "react";
import { ClipLoader } from "react-spinners";
import { toast, ToastContainer } from "react-toastify";
import { db } from "../firebase";
import { collection, getDocs, doc, getDoc, updateDoc } from "firebase/firestore";

export default function UserDailyEntry() {
    var [entries, setEntries] = useState([]);
    var [load, setLoad] = useState(false);
    var userId = sessionStorage.getItem("userId"); // logged-in user

    useEffect(() => {
        fetchEntries();
    }, []);

    const fetchEntries = () => {
        if (!userId) return; // safety check

        setLoad(true);
        getDocs(collection(db, "dailyEntries"))
            .then((snap) => {
                let data = [];
                let hasMatch = false;

                snap.docs.forEach((d) => {
                    if (d.data().userId === userId) {
                        hasMatch = true;
                        getDoc(doc(db, "users", d.data().userId))
                            .then((uDoc) => {
                                data.push({
                                    id: d.id,
                                    userName: uDoc.exists() ? uDoc.data().name : "Unknown",
                                    ...d.data()
                                });
                                setEntries([...data]);
                                setLoad(false);
                            })
                            .catch((err) => {
                                toast.error(err.message);
                                setEntries([...data]);
                                setLoad(false);
                            });
                    }
                });

                if (!hasMatch) {
                    setEntries([]);
                    setLoad(false);   // ✅ ensures loader stops even when no entries
                }
            })

            .catch((err) => {
                toast.error(err.message);
                setLoad(false);
            });
    };



    return (
        <>
            {/* Header Start */}
            <div className="container-fluid py-5 bg-dark hero-header mb-5">
                <div className="container text-center my-5 pt-5 pb-4">
                    <h1 className="display-3 text-white mb-3 animated slideInDown">
                        View Daily Deliveries
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb justify-content-center text-uppercase">
                            <li className="breadcrumb-item"><a href="#">Home</a></li>
                            <li className="breadcrumb-item"><a href="#">Pages</a></li>
                            <li className="breadcrumb-item text-white active" aria-current="page">
                                Daily Deliveries
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            {/* Header End */}

            <div className="container-fluid py-5">
                <div className="container">
                    <ToastContainer />
                    <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
                    {!load && entries.length > 0 ? (
                        <>

                            <div className="table-responsive shadow">

                                <>
                                    <table className="table table-bordered text-center">
                                        <thead className="table-dark">
                                            <tr>
                                                <th>User Name</th>
                                                <th>Date</th>
                                                <th>Meal</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {entries?.map((e) => (
                                                <tr key={e.id}>
                                                    <td>{e.userName}</td>
                                                    <td>{e.date}</td>
                                                    <td>{e.mealType}</td>
                                                    <td>{e.price}</td>
                                                    <td>{e.isPaid ? "Paid" : "Unpaid"}</td>
                                                    <td>{e.createdAt?.toDate().toLocaleString()}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>


                                </>

                            </div>


                        </>
                    ) : !load && <h3 className="text-center">No Entries Found</h3>}
                </div>
            </div>
        </>
    );
}
