import { collection, getDocs, doc, getDoc, updateDoc, addDoc, Timestamp } from "firebase/firestore";

import { useEffect, useState } from "react";
import { ClipLoader } from "react-spinners";
import { toast, ToastContainer } from "react-toastify";
import { db } from "../firebase";
import { useNavigate } from "react-router-dom";

export default function ViewBill() {
    var [entries, setEntries] = useState([]);
    var [load, setLoad] = useState(false);
    
    var userId = sessionStorage.getItem("userId"); // logged-in user
    const nav = useNavigate()

    useEffect(() => {
        fetchEntries();
    }, []);

    const fetchEntries = () => {
        if (!userId) return; // safety check

        setLoad(true);
        getDocs(collection(db, "dailyEntries"))
            .then((snap) => {
                let data = [];
                let hasMatch = false;

                snap.docs.forEach((d) => {
                    if (d.data().userId === userId) {
                        hasMatch = true;
                        getDoc(doc(db, "users", d.data().userId))
                            .then((uDoc) => {
                                data.push({
                                    id: d.id,
                                    userName: uDoc.exists() ? uDoc.data().name : "Unknown",
                                    ...d.data()
                                });
                                setEntries([...data]);
                                console.log([...data]);
                                setLoad(false);
                            })
                            .catch((err) => {
                                toast.error(err.message);
                                setEntries([...data]);
                                setLoad(false);
                            });
                    }
                });

                if (!hasMatch) {
                    setEntries([]);
                    setLoad(false);   // ✅ stops infinite loader
                }
            })

            .catch((err) => {
                toast.error(err.message);
                setLoad(false);
            });
    };



    // Flips isPaid to true for all unpaid rows currently shown.

    const markEntriesPaidAndLog = async ({ paymentId, amount }) => {
        try {
            const unpaid = entries.filter(e => !e.isPaid);              // current table filter
            const entryIds = unpaid.map(e => e.id);

            // 1) Flip status for all unpaid entries
            for (let id of entryIds) {
                await updateDoc(doc(db, "dailyEntries", id), { isPaid: true });
            }

            // 2) Save a compact payment doc (batch)
            await addDoc(collection(db, "paymentBatches"), {
                userId,                       // from session (already in your file)
                paymentId,                    // Razorpay txn id
                entryIds,                     // all entries paid together
                count: entryIds.length,       // how many
                amount,                       // rupees you passed to Razorpay
                createdAt: Timestamp.now()
            });

            toast.success("Payment successful!");
            fetchEntries();
        } catch (err) {
            toast.error("Post-payment update failed: " + err.message);
            throw err; // rethrow so caller can handle if needed
        }
    };

    // handlePayment

    const handlePayment = async (amtInRupees) => {
        const options = {
            key: "rzp_test_Q8bKRaQdmgftXW",   // test key
            amount: amtInRupees * 100,        // paise
            currency: "INR",
            name: "Annpan",
            description: "Daily Meal Payment",
            handler: async function (response) {
                try {
                    await markEntriesPaidAndLog({
                        paymentId: response.razorpay_payment_id,
                        amount: amtInRupees,
                    });

                    // optional: navigate like your old flow
                    setTimeout(() => nav("/viewbill"), 1500);
                } catch (e) {
                    // already toasted in helper
                }
            },
            prefill: {
                name: "User",
                email: sessionStorage.getItem("email") || "test@example.com",
                contact: "9999999999",
            },
            notes: { address: "Test Address" },
            theme: { color: "#3399cc" },
        };

        const rzp = new window.Razorpay(options);

        // Payment failure / dismissed
        rzp.on("payment.failed", function () {
            toast.error("Payment failed or cancelled.");
        });

        rzp.open();
    };



    return (
        <>
            {/* Header Start */}
            <div className="container-fluid py-5 bg-dark hero-header mb-5">
                <div className="container text-center my-5 pt-5 pb-4">
                    <h1 className="display-3 text-white mb-3 animated slideInDown">
                        View Daily Deliveries
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb justify-content-center text-uppercase">
                            <li className="breadcrumb-item"><a href="#">Home</a></li>
                            <li className="breadcrumb-item"><a href="#">Pages</a></li>
                            <li className="breadcrumb-item text-white active" aria-current="page">
                                Daily Deliveries
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            {/* Header End */}

            <div className="container-fluid py-5">
                <div className="container">
                    <ToastContainer />
                    <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
                    {!load && entries.length > 0 ? (
                        <>

                            <div className="table-responsive shadow">
                                {entries.some(e => !e.isPaid) ? (
                                    <>
                                        <table className="table table-bordered text-center">
                                            <thead className="table-dark">
                                                <tr>
                                                    <th>User Name</th>
                                                    <th>Date</th>
                                                    <th>Meal</th>
                                                    <th>Price</th>
                                                    <th>Status</th>
                                                    <th>Created At</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {



                                                    entries.filter(e => !e.isPaid).map((e) => {
                                                        console.log("Price of each item is :", e.price);

                                                        return (

                                                            <tr key={e.id}>
                                                                <td>{e.userName}</td>
                                                                <td>{e.date}</td>
                                                                <td>{e.mealType}</td>
                                                                <td>{e.price}</td>
                                                                <td>{e.isPaid ? "Paid" : "Unpaid"}</td>
                                                                <td>{e.createdAt?.toDate().toLocaleString()}</td>
                                                            </tr>
                                                        )

                                                    })}
                                            </tbody>
                                        </table>

                                        <div className="text-center mt-3">
                                            <button
                                                className="btn btn-success mb-3"
                                                onClick={() => {

                                                    const unpaidEntries = entries.filter(e => !e.isPaid);
                                                    const totalPayablePrice = unpaidEntries.reduce((sum, e) => sum + Number(e.price), 0);

                                                    handlePayment(totalPayablePrice)

                                                }}   // <- set your real amount (in ₹)
                                            >
                                                Pay
                                            </button>

                                        </div>
                                    </>
                                ) : (
                                    <p className="text-center fw-bold">No Pending Payment</p>
                                )}
                            </div>


                        </>
                    ) : !load && <h3 className="text-center">No Entries Found</h3>}
                </div>
            </div>
        </>
    );
}
