import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { ClipLoader } from "react-spinners"
import { toast, ToastContainer } from "react-toastify"
import { createUserWithEmailAndPassword, GoogleAuthProvider, signInWithEmailAndPassword, signInWithPopup } from "firebase/auth"
import { auth, db } from "../Firebase"
import { addDoc, collection, doc, getDoc, setDoc, Timestamp } from "firebase/firestore"
import axios from "axios"


export default function Addcategory() {
  // var[Name,]
  //  var[a,seta]=useState(10)
  // seta(20)

  var [Name, setName] = useState("")
  // var[Description,setDescription]=useState("")
  // var[type,settype]=useState("")
  // var[price,setprice]=useState("")
  var [Image, setImage] = useState("")
  var [load, setLoad] = useState(false)
  var [url, setUrl] = useState("")
  var nav = useNavigate()

  function handleform(e) {
    e.preventDefault();

    setLoad(true);

    let data = new FormData();
    data.append("file", Image);
    data.append("upload_preset", "annpan");
    axios.post("https://api.cloudinary.com/v1_1/dqldac5ij/image/upload", data)
      .then((res) => {
        savedata(res.data.secure_url);   // pass url directly
      })
      .catch((err) => {
        toast.error(err.message);
      });
  }

  const savedata = async (imageUrl) => {
    let data = {
      name: Name,
      image: imageUrl,
      status: true,
      createdAt: Timestamp.now()
    };
    await addDoc(collection(db, "category"), data)
      .then(() => {
        setName("");
        toast.success("Category Added Successfully!!");
        setTimeout(() =>{ nav("/admin/managecategory") 
          
          setLoad(false)

        }, 2000);
      })
      .catch((err) => {
        toast.error(err.message)
       setTimeout(() =>{ nav("/admin/managecategory") 
          
          setLoad(false)
       }, 2000)
      }
    );
  };

  // bydefault loading time call but dependency pass
  // useEffect(()=>{
  //     if(!!url){
  //         savedata()

  //     }
  // },[url])

  return (
    <>
      {/* Header Start */}

      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Add Category
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Add Category
              </li>
            </ol>
          </nav>
        </div>
      </div>
      {/* Header End */}
      {/* About Start */}
      <div className="container-fluid py-5">
        <div className="container">
          {/* {cond?"true block":"false block"} */}
          {/* {!load?<><h1>Form show </h1><h2></h2></>:<h1>kush nhi</h1>} */}
          <ToastContainer />
          <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
          <div className="row ">
            {
              !load ?
                <div className="offset-md-2 col-md-4 mx-auto shadow p-4 ">
                  <form onSubmit={handleform}>
                    <label htmlFor="" className="form-label">Name</label>
                    <input type="text" className="form-control" value={Name} onChange={(e) => { setName(e.target.value) }} required/>

                    <label htmlFor="" className="form-label">Image</label>
                    <input type="file" className="form-control" onChange={(e) => { setImage(e.target.files[0]) }} required/>
                    {/* <label htmlFor="" className="form-label">Type</label>
                        <input type="text" className="form-control" value={type}  onChange={(e)=>{settype(e.target.value)}}/>
                        <label htmlFor="" className="form-label">Price</label>
                        <input type="text" className="form-control" value={price}  onChange={(e)=>{setprice(e.target.value)}}/>
                        <label htmlFor="" className="form-label">Description</label>
                        <input type="text" className="form-control" value={Description} onChange={(e)=>{setDescription(e.target.value)}} />
                     
                        <label htmlFor="" className="form-label">Image</label>
                        <input type="file" className="form-control"  onChange={(e)=>{setImage(e.target.files[0])}} /> */}

                    {/* <input type="file" className="form-control" onChange={changeImage}/> */}
                    <button type="submit " className="btn btn-primary mt-5">Add</button>
                  </form>
                </div>
                : ""
            }
          </div>
        </div>
      </div>
      {/* About End */}

      {/* Team End */}
    </>

  )
}