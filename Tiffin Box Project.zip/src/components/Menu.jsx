import { collection, deleteDoc, doc, onSnapshot, query, where } from "firebase/firestore"
import { db } from "../Firebase"
import { useEffect, useState } from "react"
import { toast, ToastContainer } from "react-toastify"
export default function Menu(){
  var[type,settype]=useState("breakfast")
  const [catedata, setcatedata] = useState([])
      useEffect(() => {
        
      const fatchData=()=>{
          onSnapshot(query(collection(db,"category"),where("type","==",type) ),(CategoryData)=>{
              // console.log("data",CategoryData.docs[0].data());
              setcatedata(
                  CategoryData.docs.map((el)=>{
                      // return(el.data)
                      return {id:el.id, ...el.data()}
                      
                      
                  })
              )
              
          })
      }
  
          fatchData()
        
      }, [type])
      const handlemenu=(newtype)=>{
        console.log("New type:", newtype);
         settype(newtype);
      }

    return(
        <>
          <div className="container-fluid py-5 bg-dark hero-header mb-5">
              <div className="container text-center my-5 pt-5 pb-4">
                <h1 className="display-3 text-white mb-3 animated slideInDown">
                MENU
                </h1>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb justify-content-center text-uppercase">
                    <li className="breadcrumb-item">
                      <a href="#">Home</a>
                    </li>
                    <li className="breadcrumb-item">
                      <a href="#">Pages</a>
                    </li>
                    <li className="breadcrumb-item text-white active" aria-current="page">
                     Menu
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
      <div className="container">
      <div className="row align-items-center">
        <div className="container-fluid py-5">
        <div className="container">
          <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h5 className="section-title ff-secondary text-center text-primary fw-normal">
              Food Menu
            </h5>
            <h1 className="mb-5">Most Popular Items</h1>
          </div>
          <div className="tab-class text-center wow fadeInUp" data-wow-delay="0.1s">
            <ul className="nav nav-pills d-inline-flex justify-content-center border-bottom mb-5">
              <li className="nav-item">
                <a
                  className="d-flex align-items-center text-start mx-3 ms-0 pb-3 active"
                  data-bs-toggle="pill"
                  href="#"
                   onClick={()=>handlemenu('breakfast')}
                >
                  <i className="fa fa-coffee fa-2x text-primary" />
                  <div className="ps-3">
                    <small className="text-body">Popular</small>
                    <h6 className="mt-n1 mb-0">Breakfast</h6>
                  </div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="d-flex align-items-center text-start mx-3 pb-3"
                  data-bs-toggle="pill"
                  href="#"
                 onClick={()=>handlemenu('lunch')}>
                  <i className="fa fa-hamburger fa-2x text-primary" />
                  <div className="ps-3">
                    <small className="text-body">Special</small>
                    <h6 className="mt-n1 mb-0">Lunch</h6>
                  </div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="d-flex align-items-center text-start mx-3 me-0 pb-3"
                  data-bs-toggle="pill"
                  href="#" 
                   onClick={()=>handlemenu('dinner')}
                >
                  <i className="fa fa-utensils fa-2x text-primary" />
                  <div className="ps-3">
                    <small className="text-body">Lovely</small>
                    <h6 className="mt-n1 mb-0">Dinner</h6>
                  </div>
                </a>
              </li>
            </ul>
            </div>
            </div>
            </div>
            </div>
            </div>
            {/* <div className="container">
              <div className="row align-items-center">
              {
          catedata.map((el,index)=>(
              <>
              <div className="card" style={{ width: "18rem" }}>
            <img src={el.image} className="card-img-top img-fluid" alt="..." />
            <div className="card-body">
              <h5 className="card-title">{el.name}</h5>
              <p className="card-text">
                {el.description}
              </p>
              <a href="#" className="btn btn-primary">
                Go somewhere
              </a>
      </div>
    </div>


    </>
            
          ))
        }
        </div>
        </div> */}
                  <div className="container">
                  <div className="row align-items-center">
                    
                  {
                    catedata.map((el,index)=>(
                      <>
                      <div className="col-6 d-flex mb-4">
                        <img
                    className="flex-shrink-0 img-fluid rounded"
                    src={el.image}
                    alt=""
                    style={{ width: 80 }}
                  />
                  <div className="w-100 d-flex flex-column text-start ps-4">
                    <h5 className="d-flex justify-content-between border-bottom p-2">
                      <span>{el.name}</span>
                      <span className="text-primary">$115</span>
                    </h5>
                    <small className="fst-italic">
                      {el.description}
                    </small>
                  </div>
                  </div>
                  </>
                    ))
                  }
                  
                </div>
              </div>
            
              
        </>
        )}
      