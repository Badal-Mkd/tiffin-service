import React, { useState, useEffect } from "react";
import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "../Firebase";
import { useParams } from "react-router-dom"; // ✅ for category param

export default function MenuByCategory() {
    const { categoryName } = useParams(); // ✅ get category from URL
    const [menuItems, setMenuItems] = useState([]);

    // Fetch items when categoryName changes
    useEffect(() => {
        if (!categoryName) return;

        const q = query(collection(db, "menu"), where("category", "==", categoryName));

        getDocs(q)
            .then((snapshot) => {
                const list = snapshot.docs.map((doc) => ({
                    id: doc.id,
                    ...doc.data(),
                }));
                setMenuItems(list);
                // console.log(list)
            })
            .catch((err) => {
                console.error("Error fetching menu:", err.message);
            });
    }, [categoryName]);

    return (
        <div>
  {/* Hero Header with Breadcrumb */}
  <div className="container-fluid py-5 bg-dark hero-header mb-5">
    <div className="container text-center my-5 pt-5 pb-4">
      <h1 className="display-3 text-white mb-3 animated slideInDown">
        {categoryName} Menu
      </h1>
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb justify-content-center text-uppercase">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Menu</a>
          </li>
          <li
            className="breadcrumb-item text-white active"
            aria-current="page"
          >
            {categoryName}
          </li>
        </ol>
      </nav>
    </div>
  </div>

  {/* Items Display */}
  <div className="container mt-4">
    <div className="row">
      {menuItems.length > 0 ? (
        menuItems.map((item) => (
          <div className="col-md-4 mb-3" key={item?.id}>
            <div className="card shadow h-100">
              <div className="card-body text-center">
                <img src={item?.image} className="img-fluid w-100 h-50"  alt="" />
                <h5 className="card-title my-4">{item?.day}</h5>
                <p className="card-text mb-4 fw-bold">{item?.name}</p>
                <p className="card-text">{item?.description}</p>
                <p className="card-text">{item?.price} ₹</p>
                
              </div>
            </div>
          </div>
        ))
      ) : (
        <p className="text-muted text-center">
          No items found for {categoryName}
        </p>
      )}
    </div>
  </div>
</div>


    );
}
