import { useState } from "react"
import { toast, ToastContainer } from "react-toastify"
import { ClipLoader } from "react-spinners"
import { Link, useNavigate } from "react-router-dom"
import { createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from "firebase/auth"
import { auth, db } from "../Firebase"
import { doc, setDoc, Timestamp } from "firebase/firestore"
export default function Register() {
  var [name, setname] = useState("")
  var [email, setemail] = useState("")
  var [password, setpass] = useState("")
  var [type, settype] = useState("password")
  var [type1, settype1] = useState("password")
  var [confirmpassword, setconpass] = useState("")
  var [load, setLoad] = useState(false)
  var nav = useNavigate()
  var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/;
  var passw = /^(?=.*?[A-Za-z0-9#?!@$%^&*-]).{6,}$/;

  function checkemail(e) {
    console.log("change email fun call", e.target.value);
    setemail(e.target.value)
    //          if (emailRegex.test(email)) {
    //           console.log(email)
    // } else {
    //   toast.error("invaild email")
    // }
  }
  function handleform(e) {
    e.preventDefault()
    setLoad(true)
    console.log("form is submit");

    //  if (emailRegex.test(email)) {
    //   toast.success("Welcome  " +name)
    // } else {
    //   toast.error("invaild email")
    // }
    if (email == "admin@gmail.com") {
      toast.success("admin login!!")
      setTimeout(() => {
        setLoad(false)
        nav("/admin")
      }, 4000)
    }
    else if (emailRegex.test(email) && passw.test(password) && (password == confirmpassword)) {
      createUserWithEmailAndPassword(auth, email, password)
        .then((usercred) => {
          savedata(usercred.user.uid, email, name)
        })
        .catch((err) => {
          toast.error(err.message)
        })
      toast.success("Welcome  " + name)
      setTimeout(() => {
        setLoad(false)
        nav("/")
      }, 4000);
    }

    else {
      if (!emailRegex.test(email)) {
        toast.error("Invalid email format");
      } else if (!passw.test(password)) {
        toast.error("Password must be at least 6 characters");
      } else if (password !== confirmpassword) {
        toast.error("Passwords do not match");
      } else if (!name) {
        toast.error("Name is required");
      } else {
        toast.error("Invalid value");
      }
      setLoad(false);
    }
  }

  var signUpWithGoogle = () => {
    // sign up using google
    let provider = new GoogleAuthProvider()
    signInWithPopup(auth, provider)
      .then((usercred) => {
        savedata(usercred.user.uid, usercred.user.email, usercred.user.displayName)
      })
      .catch((err) => {
        toast.error(err.message)
      })

  }
  let savedata = async (uid, email, name) => {
    let data = {
      name: name,
      email: email,
      userId: uid,
      // 1->Admin,2->user  users
      userType: 2,
      status: true,
      createdAt: Timestamp.now()
    }
    await setDoc(doc(db, "users", uid), data)
      .then(() => {
        // browser storages - session and local
        sessionStorage.setItem("name", name)
        sessionStorage.setItem("email", email)
        sessionStorage.setItem("uid", uid)
        sessionStorage.setItem("isLogin", true)
        sessionStorage.setItem("userType", 2)
        toast.success("User registered Successfully!!")
        setTimeout(() => {
          setLoad(false)
          nav("/")
        }, 4000);

      })
      .catch((err) => {
        toast.error(err?.message)
      })

  }




  return (
    <>
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        {/* <div className="container text-center my-5 pt-5 pb-4"> */}
        <ToastContainer />
        {/* <h1 className="display-3 text-white mb-3 animated slideInDown">
        Register
      </h1>
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb justify-content-center text-uppercase">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Pages</a>
          </li>
          <li className="breadcrumb-item text-white active" aria-current="page">
            Register
          </li>
        </ol> */}
        {/* </nav> */}
        {/* </div> */}
      </div>
      {/* Navbar & Hero End */}
      {/* Reservation Start */}
      <div className="container-xxl py-5 px-0 wow fadeInUp" data-wow-delay="0.1s">
        <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
        {!load ?
          <div className="row g-0">
            <div className="col-md-6 ">
              <div >
                <img className=" w-100 h-100" src="assets/img/regillus.avif" alt="" />
              </div>
            </div>
            <div className="col-md-6  d-flex align-items-center">
              <div className="p-5 wow fadeInUp text-center" data-wow-delay="0.2s">
                <h1 className="section-title ff-secondary  text-primary fw-normal mb-5">
                  Register
                </h1>
                <h4 className="text-black mb-4">Kindly fill in this form to Register</h4>
                <form onSubmit={handleform}>
                  <div className="row g-3">
                    <div className="col-md-12">
                      <div className="form-floating">
                        <input
                          type="text"
                          className="form-control"
                          id="name"
                          placeholder="Your Name"
                          value={name} onChange={(e) => { setname(e.target.value) }}
                          required
                        />
                        <label htmlFor="name">Your Name</label>
                      </div>
                    </div>
                    <div className="col-md-12">
                      <div className="form-floating">
                        <input
                          type="email"
                          className="form-control"
                          id="email"
                          placeholder="Your Email"
                          value={email} onChange={checkemail}
                          required
                        />
                        <label htmlFor="email">Your Email</label>
                      </div>
                    </div>
                    <div className="col-md-12 ">

                      <div
                        className="form-floating input-group"
                        id="date3"
                        data-target-input="nearest"

                      >
                        <input
                          type={type}
                          className="form-control "
                          placeholder="Password"
                          value={password} onChange={(e) => { setpass(e.target.value) }}
                          required

                        />


                        <label htmlFor="datetime">Password</label>

                        <span className="input-group-text" onClick={() => settype(type === 'password' ? 'text' : 'password')}>
                          <i className={type === 'password' ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye'}></i>
                        </span>


                      </div>
                    </div>
                    <div className="col-md-12 ">

                      <div
                        className="form-floating input-group"
                        id="date3"
                        data-target-input="nearest"

                      >
                        <input
                          type={type1}
                          className="form-control "
                          placeholder="Confirm Password"
                          value={confirmpassword} onChange={(e) => { setconpass(e.target.value) }}
                          required

                        />


                        <label htmlFor="datetime">Confirm Password</label>

                        <span className="input-group-text" onClick={() => settype1(type1 === 'password' ? 'text' : 'password')}>
                          <i className={type1 === 'password' ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye'}></i>
                        </span>


                      </div>
                    </div>

                    {/* <div className="col-12">
                <div className="form-floating">
                  <textarea
                    className="form-control"
                    placeholder="Special Request"
                    id="message"
                    style={{ height: 100 }}
                    defaultValue={""}
                  />
                  <label htmlFor="message">Special Request</label>
                </div>
              </div> */}
                    <div className="col-12">
                      <button className="btn btn-primary w-100 py-3" type="submit">
                        Register Now
                      </button>
                    </div>

                  </div>
                </form>
                <div className="row">
                  <div className="col-12">
                    {/* <button className="btn btn-secondary w-100 py-3 mt-2" type="submit" onClick={signUpWithGoogle}>
                      sign up with google
                    </button> */}
                  </div>
                  <div className="col-12">
                    <div>
                      <span>
                        Already have an account?
                        <Link to="/login"> Log in</Link>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          : ""}
      </div>
      <div
        className="modal fade"
        id="videoModal"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content rounded-0">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Youtube Video
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              />
            </div>
            <div className="modal-body">
              {/* 16:9 aspect ratio */}
              <div className="ratio ratio-16x9">
                <iframe
                  className="embed-responsive-item"
                  src=""
                  id="video"
                  allowFullScreen=""
                  allowscriptaccess="always"
                  allow="autoplay"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Reservation Start */}
    </>

  )
}