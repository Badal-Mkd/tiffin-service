import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { ClipLoader } from "react-spinners"
import { toast, ToastContainer } from "react-toastify"
import { db } from "../Firebase"
import { addDoc, collection, Timestamp } from "firebase/firestore"

export default function SendBooking() {

  var [customerName, setCustomerName] = useState("")
  var [email, setEmail] = useState("")
  var [startingDate, setStartingDate] = useState("")
  var [request, setRequest] = useState("")
  var [message, setMessage] = useState("")
  var [load, setLoad] = useState(false)
  var nav = useNavigate()

  useEffect(() => {
    if (sessionStorage.userType !== "2" || !sessionStorage.email) {
      // navigate to login and pass an error message via location.state
      nav("/login", {
        state: {
          from: "sendbooking",
          msg: "Unauthorized Access! Please login to continue."
        }
      });
    }
  }, [nav]);

  function handleform(e) {
    e.preventDefault();


    if (!customerName || !email || !startingDate || !request || !message) {
      toast.error("All fields are required!", { position: "top-center" });
      return; // stop here, don’t send
    }

    setLoad(true)
    let data = {
      customerName,
      email,
      startingDate,
      request,
      message,
      status: "pending",
      createdAt: Timestamp.now()
    };
    addDoc(collection(db, "bookings"), data)
      .then(() => {
        setCustomerName("")
        setEmail("")
        setStartingDate("")
        setRequest("")
        setMessage("")
        toast.success("Your booking request is sent!!")
        setTimeout(() => nav("/"), 4000)
      })
      .catch((err) => toast.error(err.message))
      .finally(() => setLoad(false))
  }

  return (
    <>
      {/* Header Start */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Send Booking
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Send Booking
              </li>
            </ol>
          </nav>
        </div>
      </div>
      {/* Header End */}

      {/* Form Start */}
      <div className="container-fluid py-5">
        <div className="container">
          <ToastContainer />
          <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
          <div className="row ">
            {
              !load ?
                <div className="offset-md-2 col-md-4 mx-auto shadow p-4 ">
                  <form onSubmit={handleform}>
                    <label className="form-label">Customer Name</label>
                    <input type="text" className="form-control" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />

                    <label className="form-label">Email</label>
                    <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} />

                    <label className="form-label">Starting Date</label>
                    <input type="date" min={new Date().toISOString().split("T")[0]} className="form-control" value={startingDate} onChange={(e) => setStartingDate(e.target.value)} />

                    <label className="form-label">Request</label>
                    <input type="text" className="form-control" value={request} onChange={(e) => setRequest(e.target.value)} />

                    <label className="form-label">Message</label>
                    <textarea className="form-control" value={message} onChange={(e) => setMessage(e.target.value)} />

                    <button type="submit" className="btn btn-primary mt-5">Send</button>
                  </form>
                </div>
                : ""
            }
          </div>
        </div>
      </div>
      {/* Form End */}
    </>
  )
}
