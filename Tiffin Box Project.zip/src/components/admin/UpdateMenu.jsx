import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { db } from "../../firebase"; // firebase config
import { doc, getDoc, updateDoc, collection, getDocs } from "firebase/firestore";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ClipLoader } from "react-spinners"


export default function UpdateMenu() {
  const { id } = useParams();
  const navigate = useNavigate();

  var [load, setLoad] = useState(false)

  // form states
  const [day, setDay] = useState("");
  const [category, setCategory] = useState("");
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [file, setFile] = useState(null);
  const [categories, setCategories] = useState([]);
  var [load, setLoad] = useState(false)


  // fetch existing menu item
  useEffect(() => {
    const fetchMenu = async () => {
      try {
        const docRef = doc(db, "menu", id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setDay(data.day || "");
          setCategory(data.category || "");
          setName(data.name || "");
          setPrice(data.price || "");
          setDescription(data.description || "");
          setImage(data.image || "");
        } else {
          toast.error("Menu item not found");
        }
      } catch (err) {
        console.error(err);
        toast.error("Error fetching menu item");
      }
    };
    fetchMenu();
  }, [id]);

  // fetch categories dynamically
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "category")); // ⚠️ use your collection name
        const list = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setCategories(list);
      } catch (err) {
        console.error(err);
        toast.error("Error fetching categories");
      }
    };
    fetchCategories();
  }, []);

  // file upload
  const uploadImage = async () => {
    if (!file) return image;
    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", "annpan"); // replace
    const res = await axios.post(
      "https://api.cloudinary.com/v1_1/dqldac5ij/image/upload", // replace
      formData
    );
    return res.data.secure_url;
  };

  // handle update
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const imgUrl = await uploadImage();
      const docRef = doc(db, "menu", id);
      await updateDoc(docRef, {
        day,
        category,
        name,
        price,
        description,
        image: imgUrl,
      });
      toast.success("Menu updated successfully");
      setTimeout(() => navigate("/admin/managemenu"), 1500);
    } catch (err) {
      console.error(err);
      toast.error("Error updating menu");
    }
  };

  return (
    <>
  <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />


      {/* ===== Hero Header with Breadcrumb ===== */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Update Menu
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="/admin/dashboard">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="/admin/managemenu">Manage Menu</a>
              </li>
              <li
                className="breadcrumb-item text-white active"
                aria-current="page"
              >
                Update Menu
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* ===== Update Form ===== */}
      <div className="container-fluid py-5">
        <div className="container">
          <ToastContainer />
          <div className="row">
            <div className="offset-md-2 col-md-8 shadow p-4">
              <form onSubmit={handleSubmit}>
                {/* Day */}
                <label className="form-label">Select Day</label>
                <select
                  className="form-control mb-3"
                  value={day}
                  onChange={(e) => setDay(e.target.value)}
                  required
                >
                  <option value="">Select Day</option>
                  <option>Monday</option>
                  <option>Tuesday</option>
                  <option>Wednesday</option>
                  <option>Thursday</option>
                  <option>Friday</option>
                  <option>Saturday</option>
                  <option>Sunday</option>
                </select>

                {/* Category */}
                <label className="form-label">Select Category</label>
                <select
                  className="form-control mb-3"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  required
                >
                  <option value="">Select Category</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>

                {/* Name */}
                <label className="form-label">Dish Name</label>
                <input
                  type="text"
                  className="form-control mb-3"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />

                {/* Price */}
                <label className="form-label">Price</label>
                <input
                  type="number"
                  className="form-control mb-3"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  required
                  min={1}
                />

                {/* Description */}
                <label className="form-label">Description</label>
                <textarea
                  className="form-control mb-3"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />

                {/* Old Image */}
                {image && (
                  <div className="mb-3">
                    <label className="form-label">Old Image</label>
                    <br />
                    <img
                      src={image}
                      alt="menu"
                      width="120"
                      className="rounded shadow-sm"
                    />
                  </div>
                )}

                {/* File input */}
                <label className="form-label">Upload New Image</label>
                <input
                  type="file"
                  className="form-control mb-3"
                  onChange={(e) => setFile(e.target.files[0])}
                  accept="image/*"
                />

                {/* Submit */}
                <button type="submit" className="btn btn-primary mt-3">
                  Update Menu
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
