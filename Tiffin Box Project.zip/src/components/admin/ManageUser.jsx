import { useEffect, useState } from "react";
import { db } from "../../firebase"; 
import {
  collection,
  getDocs,
  updateDoc,
  doc
} from "firebase/firestore";
import { toast, ToastContainer } from "react-toastify";

export default function ManageUser() {
  const [users, setUsers] = useState([]);

  // fetch users
  useEffect(() => {
  getDocs(collection(db, "users"))
    .then((snapshot) => {
      const list = snapshot.docs
        .map((doc, i) => ({
          id: doc.id,
          ...doc.data(),
          srno: i + 1,
        }))
        .filter((user) => user.userType !== 1); // exclude admins

      setUsers(list);
    })
    .catch((err) => {
      toast.error("Failed to fetch users: " + err.message);
    });
}, []);


  // toggle status
  const handleToggle = (id, status) => {
    const ref = doc(db, "users", id);
    updateDoc(ref, { status: !status })
      .then(() => {
        setUsers((prev) =>
          prev.map((u) => (u.id === id ? { ...u, status: !status } : u))
        );
        toast.success("Status updated successfully");
      })
      .catch((err) => {
        toast.error("Error updating status: " + err.message);
      });
  };

  return (
    <>
      <ToastContainer />

      {/* Hero Header with breadcrumb */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Manage Users
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li
                className="breadcrumb-item text-white active"
                aria-current="page"
              >
                Manage Users
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Table Section */}
      <div className="container-fluid py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="offset-md-1 col-md-10">
              <table className="table table-bordered table-hover">
                <thead className="table-light">
                  <tr>
                    <th>Sr. No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {users.length > 0 ? (
                    users.map((u, i) => (
                      <tr key={u.id}>
                        <td>{i + 1}</td>
                        <td>{u.name || "N/A"}</td>
                        <td>{u.email || "N/A"}</td>
                        <td>
                          {u.status ? (
                            <span className="badge bg-success">Active</span>
                          ) : (
                            <span className="badge bg-danger">Inactive</span>
                          )}
                        </td>
                        <td>
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => handleToggle(u.id, u.status)}
                          >
                            {u.status ? "Deactivate" : "Activate"}
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5" className="text-center text-muted">
                        No users found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
