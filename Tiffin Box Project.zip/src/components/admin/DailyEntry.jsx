import { useEffect, useState } from "react";
import { db } from "../../firebase";
import { collection, addDoc, getDocs, query, where, Timestamp } from "firebase/firestore";
import { toast, ToastContainer } from "react-toastify";

export default function DailyEntry() {
    const [users, setUsers] = useState([]);
    const [userId, setUserId] = useState("");
    const [date, setDate] = useState("");
    const [mealType, setMealType] = useState("breakfast");
    const [day, setDay] = useState("");   // ✅ New state for static day dropdown
    const [menu, setMenu] = useState([]); // ✅ State for menu data

    // Fetch users + menu data
    useEffect(() => {
        const fetchUsers = async () => {
            const snap = await getDocs(collection(db, "users"));
            setUsers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        };

        const fetchMenu = async () => {
            const snap = await getDocs(collection(db, "menu"));
            setMenu(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            console.log(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        };

        fetchUsers();
        fetchMenu();
    }, []);

    // const handleSubmit = async () => {
    //     if (!userId || !date || !mealType || !day) {
    //         toast.error("All fields required!");
    //         return;
    //     }

    //     const q = query(
    //         collection(db, "dailyEntries"),
    //         where("userId", "==", userId),
    //         where("date", "==", date),
    //         where("mealType", "==", mealType)
    //     );

    //     const snap = await getDocs(q);
    //     if (!snap.empty) {
    //         toast.error(`Entry for ${mealType} already exists for this date!`);
    //         return;
    //     }

    //     // ✅ Find price from menu
    //     let matched = menu.find(
    //         m => m.day.toLowerCase() === day.toLowerCase() &&
    //              m.category.toLowerCase() === mealType.toLowerCase()
    //     );
    //     let price = matched ? matched.price : 0;

    //     await addDoc(collection(db, "dailyEntries"), {
    //         userId,
    //         date,
    //         mealType,
    //         day,              // ✅ Save selected day
    //         price,            // ✅ Save price from menu
    //         isPaid: false,    // ✅ By default false
    //         status: "delivered",
    //         createdAt: Timestamp.now()
    //     })
    //         .then(() => {
    //             toast.success("Daily entry added!");
    //             setUserId("");
    //             setDate("");
    //             setMealType("breakfast");
    //             setDay("");
    //         })
    //         .catch((err) => toast.error(err.message));
    // };


    // ...existing code...
    const handleSubmit = async () => {
        if (!userId || !date || !mealType || !day) {
            toast.error("All fields required!");
            return;
        }

        // Check if menu item exists for selected day and category
        const matched = menu.find(
            m => m.day.toLowerCase() === day.toLowerCase() &&
                m.category.toLowerCase() === mealType.toLowerCase()
        );
        if (!matched) {
            toast.error(`Menu for ${day} - ${mealType} does not exist!`);
            return;
        }

        const q = query(
            collection(db, "dailyEntries"),
            where("userId", "==", userId),
            where("date", "==", date),
            where("mealType", "==", mealType)
        );

        const snap = await getDocs(q);
        if (!snap.empty) {
            toast.error(`Entry for ${mealType} already exists for this date!`);
            return;
        }

        let price = Number(matched.price);

        await addDoc(collection(db, "dailyEntries"), {
            userId,
            date,
            mealType,
            day,
            price,
            isPaid: false,
            status: "delivered",
            createdAt: Timestamp.now()
        })
            .then(() => {
                toast.success("Daily entry added!");
                setUserId("");
                setDate("");
                setMealType("breakfast");
                setDay("");
            })
            .catch((err) => toast.error(err.message));
    };


    return (
        <>
            {/* Header Start */}
            <div className="container-fluid py-5 bg-dark hero-header mb-5">
                <div className="container text-center my-5 pt-5 pb-4">
                    <h1 className="display-3 text-white mb-3 animated slideInDown">
                        Add Entry
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb justify-content-center text-uppercase">
                            <li className="breadcrumb-item"><a href="#">Home</a></li>
                            <li className="breadcrumb-item"><a href="#">Pages</a></li>
                            <li className="breadcrumb-item text-white active" aria-current="page">
                                Add Entry
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            {/* Header End */}

            <div className="container mt-4">
                <ToastContainer />

                <div className="row justify-content-center">
                    <div className="col-md-6">
                        <h3>Add Daily Entry</h3>

                        <div className="mb-3">
                            <label>User</label>
                            <select className="form-control" value={userId} onChange={e => setUserId(e.target.value)}>
                                <option value="">Select User</option>
                                {users
                                    .filter(u => u.email !== "admin@gmail.com")
                                    .map(u => (
                                        <option key={u.id} value={u.id}>
                                            {u.name}
                                        </option>
                                    ))}
                            </select>
                        </div>

                        <div className="mb-3">
                            <label>Date</label>
                            <input type="date" className="form-control" value={date} min={new Date().toISOString().split("T")[0]} onChange={e => setDate(e.target.value)} />
                        </div>

                        <div className="mb-3">
                            <label>Day</label>
                            <select className="form-control" value={day} onChange={e => setDay(e.target.value)}>
                                <option value="">Select Day</option>
                                <option value="Monday">Monday</option>
                                <option value="Tuesday">Tuesday</option>
                                <option value="Wednesday">Wednesday</option>
                                <option value="Thursday">Thursday</option>
                                <option value="Friday">Friday</option>
                                <option value="Saturday">Saturday</option>
                                <option value="Sunday">Sunday</option>
                            </select>
                        </div>

                        <div className="mb-3">
                            <label>Meal</label>
                            <select className="form-control" value={mealType} onChange={e => setMealType(e.target.value)}>
                                <option value="breakfast">Breakfast</option>
                                <option value="lunch">Lunch</option>
                                <option value="dinner">Dinner</option>
                            </select>
                        </div>

                        <button className="btn btn-primary" onClick={handleSubmit}>Save Entry</button>
                    </div>
                </div>
            </div>
        </>
    );
}
