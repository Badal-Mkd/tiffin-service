import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { ClipLoader } from "react-spinners"
import { toast, ToastContainer } from "react-toastify"
import { db } from "../../Firebase"
import { addDoc, collection, onSnapshot, Timestamp, query, where, getDocs } from "firebase/firestore"
import axios from "axios"

export default function AddMenuItem() {

  var [Day, setDay] = useState("")
  var [Category, setCategory] = useState("")
  var [Name, setName] = useState("")
  var [Price, setPrice] = useState("")
  var [Image, setImage] = useState("")
  var [Description, setDescription] = useState("")
  var [load, setLoad] = useState(false)
  var [catedata, setCatedata] = useState([])

  var nav = useNavigate()

  // fetch categories from firebase
  useEffect(() => {
    const fatchData = () => {
      onSnapshot(collection(db, "category"), (CategoryData) => {
        setCatedata(
          CategoryData.docs.map((el) => {
            return { id: el.id, ...el.data() }
          })
        )
      })
    }
    fatchData()
  }, [])

  // days array
  var days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

  function handleform(e) {
    e.preventDefault()
    setLoad(true)
    let data = new FormData()
    data.append("file", Image)
    data.append("upload_preset", "annpan")
    axios.post("https://api.cloudinary.com/v1_1/dqldac5ij/image/upload", data)
      .then((res) => {
        savedata(res.data.secure_url)
      })
      .catch((err) => {
        setLoad(false)
        toast.error(err.message)
      })
  }

 const savedata = async (imageUrl) => {
  let q = query(
    collection(db, "menu"),
    where("day", "==", Day),
    where("category", "==", Category)
  )

  let snap = await getDocs(q)
  if (!snap.empty) {
    setLoad(false)
    toast.error("Only one item allowed in this category for the selected day!")
    return
  }

  let data = {
    day: Day,
    category: Category,
    name: Name,
    price: Price,
    image: imageUrl,
    description: Description,
    createdAt: Timestamp.now()
  }

  await addDoc(collection(db, "menu"), data)
    .then(() => {
      setDay("")
      setCategory("")
      setName("")
      setPrice("")
      setImage("")
      setDescription("")
      setLoad(false)
      toast.success("Menu Item Added Successfully!!")
      setTimeout(() => nav("/admin/managemenu"), 2000)
    })
    .catch((err) => {
      setLoad(false)
      toast.error(err.message)
    })
}
  return (
    <>
      {/* Header Start */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Add Menu
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item"><a href="#">Home</a></li>
              <li className="breadcrumb-item"><a href="#">Pages</a></li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Add Menu
              </li>
            </ol>
          </nav>
        </div>
      </div>
      {/* Header End */}

      <div className="container-fluid py-5">
        <div className="container">
          <ToastContainer />
          <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
          <div className="row">
            {
              !load ?
                <div className="offset-md-2 col-md-4 mx-auto shadow p-4">
                  <form onSubmit={handleform}>

                    <label className="form-label">Day</label>
                    <select className="form-control" value={Day} onChange={(e) => setDay(e.target.value)} required>
                      <option value="">Select Day</option>
                      {days.map((d, i) => <option key={i} value={d}>{d}</option>)}
                    </select>

                    <label className="form-label">Category</label>
                    <select className="form-control" value={Category} onChange={(e) => setCategory(e.target.value)} required>
                      <option value="">Select Category</option>
                      {catedata.map((cat) => (
                        <option key={cat.id} value={cat.name}>{cat.name}</option>
                      ))}
                    </select>

                    <label className="form-label">Name</label>
                    <input type="text" className="form-control" value={Name} onChange={(e) => setName(e.target.value)} required />

                    <label className="form-label">Price</label>
                    <input type="number" className="form-control" value={Price} min={1} onChange={(e) => setPrice(e.target.value)} required />

                    <label className="form-label">Image</label>
                    <input type="file" className="form-control" onChange={(e) => setImage(e.target.files[0])} required />

                    <label className="form-label">Description</label>
                    <textarea className="form-control" value={Description} onChange={(e) => setDescription(e.target.value)} required />

                    <button type="submit" className="btn btn-primary mt-4">Add</button>
                  </form>
                </div>
                : ""
            }
          </div>
        </div>
      </div>
    </>
  )
}
