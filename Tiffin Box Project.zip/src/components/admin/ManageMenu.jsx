import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";
import { db } from "../../firebase";

export default function ManageMenu() {
  const [menu, setMenu] = useState([]);

  // Fetch menu data
  useEffect(() => {
    async function getMenu() {
      const querySnapshot = await getDocs(collection(db, "menu"));
      const menuArray = [];
      querySnapshot.forEach((docSnap) => {
        menuArray.push({ id: docSnap.id, ...docSnap.data() });
      });
      setMenu(menuArray);
    }
    getMenu();
  }, []);

  // Delete menu item
  const deleteMenu = async (id) => {
    try {
      await deleteDoc(doc(db, "menu", id));
      toast.success("Menu deleted successfully!");
      setMenu(menu.filter((item) => item.id !== id)); // update UI instantly
    } catch (error) {
      toast.error("Error deleting menu!");
    }
  };

  return (
    <>
      <ToastContainer />
      
      {/* Hero Header with Breadcrumb */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Manage Menu
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li
                className="breadcrumb-item text-white active"
                aria-current="page"
              >
                Manage Menu
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Table Section */}
      <div className="container-fluid py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="offset-md-1 col-md-10">
              <table className="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr No.</th>
                    <th>Day</th>
                    <th>Category</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Created At</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {menu.map((item,index) => (
                    <tr key={item.id}>
                      <td>{index+1}</td>
                      <td>{item.day}</td>
                      <td>{item.category}</td>
                      <td>{item.name}</td>
                      <td>₹{item.price}</td>
                      <td>{item.description}</td>
                      <td>
                        {item.image && (
                          <img
                            src={item.image}
                            alt={item.name}
                            width="60"
                            height="60"
                            style={{ objectFit: "cover", borderRadius: "5px" }}
                          />
                        )}
                      </td>
                      <td>
                        {item.createdAt
                          ? new Date(item.createdAt.seconds * 1000).toLocaleString()
                          : "N/A"}
                      </td>
                      <td className="d-flex">
                        <Link
                          to={"/admin/updatemenu/" + item.id}
                          className="btn btn-primary btn-sm me-2"
                        >
                          Update
                        </Link>
                        <button
                          className="btn btn-danger btn-sm "
                          onClick={() => deleteMenu(item.id)}
                        >
                          Delete
                        </button>
                        
                      </td>
                    </tr>
                  ))}
                  {menu.length === 0 && (
  <tr>
    <td colSpan="8" className="text-center">No data available</td>
  </tr>
)}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
