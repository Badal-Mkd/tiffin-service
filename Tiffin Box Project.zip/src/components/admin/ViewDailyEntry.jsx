import { useEffect, useState } from "react";
import { ClipLoader } from "react-spinners";
import { toast, ToastContainer } from "react-toastify";
import { db } from "../../firebase";
import { collection, getDocs, doc, getDoc } from "firebase/firestore";

export default function ViewDailyEntry() {
  var [entries, setEntries] = useState([]);
  var [load, setLoad] = useState(false);
  var [search, setSearch] = useState("");

  useEffect(() => {
    fetchEntries();
  }, []);

  const fetchEntries = () => {
    setLoad(true);
    getDocs(collection(db, "dailyEntries"))
      .then((snap) => {
        let data = [];
        if (snap.docs.length === 0) {
          setEntries([]);
          setLoad(false);
          return;
        }

        snap.docs.forEach((d) => {
          getDoc(doc(db, "users", d.data().userId))
            .then((uDoc) => {
              data.push({
                id: d.id,
                userName: uDoc.exists() ? uDoc.data().name : "Unknown",
                ...d.data()
              });
              setEntries([...data]); // update state each time
              setLoad(false);
            })
            .catch((err) => {
              toast.error(err.message);
              setEntries([...data]);
              setLoad(false);
            });
        });
      })
      .catch((err) => {
        toast.error(err.message);
        setLoad(false);
      });
  };

  // Filtered entries based on search input
  var filteredEntries = entries.filter((e) =>
  e.userName.toLowerCase().includes(search.toLowerCase())
);


  return (
    <>
      {/* Header Start */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            View Daily Entries
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item"><a href="#">Home</a></li>
              <li className="breadcrumb-item"><a href="#">Pages</a></li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Daily Entries
              </li>
            </ol>
          </nav>
        </div>
      </div>
      {/* Header End */}

      <div className="container-fluid py-5">
        <div className="container">
          <ToastContainer />
          <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />

          {/* Filter input */}
          {!load && entries.length > 0 && (
            <div className="mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Search by User Name"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          )}

          {!load && filteredEntries.length > 0 ? (
            <div className="table-responsive shadow">
              <table className="table table-bordered text-center">
                <thead className="table-dark">
                  <tr>
                    <th>Sr No.</th>
                    <th>User Name</th>
                    <th>Date</th>
                    <th>Meal</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Created At</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEntries.map((e,index) => (
                    <tr key={e.id}>
                      <td>{index+1}</td>
                      <td>{e.userName}</td>
                      <td>{e.date}</td>
                      <td>{e.mealType}</td>
                      <td>{e.price} ₹</td>
                      <td>{e.isPaid?"Paid":"Unpaid"}</td>
                      <td>{e.createdAt?.toDate().toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : !load && <h3 className="text-center">No Entries Found</h3>}
        </div>
      </div>
    </>
  );
}
