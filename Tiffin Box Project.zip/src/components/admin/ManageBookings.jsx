import { useEffect, useState } from "react"
import { ClipLoader } from "react-spinners"
import { toast, ToastContainer } from "react-toastify"
import { db } from "../../Firebase"
import { collection, getDocs, updateDoc, doc } from "firebase/firestore"

export default function ManageBookings() {

    var [bookings, setBookings] = useState([])
    var [load, setLoad] = useState(false)

    useEffect(() => {
        fetchBookings()
    }, [])

    function fetchBookings() {
        setLoad(true)
        getDocs(collection(db, "bookings"))
            .then((snap) => {
                let data = []
                snap.forEach((d) => {
                    data.push({ id: d.id, ...d.data() })
                })
                setBookings(data)
            })
            .catch((err) => {
                toast.error(err.message)
            })
            .finally(() => {
                setLoad(false)
            })
    }

    function handleStatus(id, status) {
        updateDoc(doc(db, "bookings", id), { status })
            .then(() => {
                toast.success(`Booking ${status}!`)
                setBookings((prev) =>
                    prev.map((b) => (b.id === id ? { ...b, status } : b))
                )
            })
            .catch((err) => {
                toast.error(err.message)
            })
    }


    return (
        <>
            {/* Header Start */}
            <div className="container-fluid py-5 bg-dark hero-header mb-5">
                <div className="container text-center my-5 pt-5 pb-4">
                    <h1 className="display-3 text-white mb-3 animated slideInDown">
                        Manage Bookings
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb justify-content-center text-uppercase">
                            <li className="breadcrumb-item">
                                <a href="#">Home</a>
                            </li>
                            <li className="breadcrumb-item">
                                <a href="#">Pages</a>
                            </li>
                            <li className="breadcrumb-item text-white active" aria-current="page">
                                Manage Bookings
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            {/* Header End */}

            <div className="container-fluid py-5">
                <div className="container">
                    <ToastContainer />
                    <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
                    {
                        !load && bookings.length > 0 ?
                            <div className="table-responsive shadow">
                                <table className="table table-bordered text-center">
                                    <thead className="table-dark">
                                        <tr>
                                            <th>Sr No.</th>
                                            <th>Customer Name</th>
                                            <th>Email</th>
                                            <th>Starting Date</th>
                                            <th>Request</th>
                                            <th>Message</th>
                                            <th>Status</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            bookings.map((b,index) => (
                                                <tr key={b.id}>
                                                    <td>{index+1}</td>
                                                    <td>{b.customerName}</td>
                                                    <td>{b.email}</td>
                                                    <td>{b.startingDate}</td>
                                                    <td>{b.request}</td>
                                                    <td>{b.message}</td>
                                                    <td>{b.status}</td>
                                                    <td>{b.createdAt?.toDate().toLocaleString()}</td>
                                                    <td>
                                                        {b.status === "pending" ? (
                                                            <>
                                                                <button
                                                                    className="btn btn-primary btn-sm me-2"
                                                                    onClick={() => handleStatus(b.id, "approved")}
                                                                >
                                                                    Approve
                                                                </button>
                                                                <button
                                                                    className="btn btn-danger btn-sm mt-3"
                                                                    onClick={() => handleStatus(b.id, "rejected")}
                                                                >
                                                                    Reject
                                                                </button>
                                                            </>
                                                        ) : b.status === "approved" ? (
                                                            <button className="btn btn-primary btn-sm" disabled>
                                                                Approved
                                                            </button>
                                                        ) : (
                                                            <button className="btn btn-danger btn-sm" disabled>
                                                                Rejected
                                                            </button>
                                                        )}
                                                    </td>

                                                </tr>
                                            ))
                                        }
                                    </tbody>
                                </table>
                            </div>
                            : !load && <h3 className="text-center">No Bookings Found</h3>
                    }
                </div>
            </div>
        </>
    )
}
