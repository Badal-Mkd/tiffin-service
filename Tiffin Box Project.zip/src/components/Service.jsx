import { useEffect, useState } from "react"
import { collection, deleteDoc, doc, onSnapshot, query, where } from "firebase/firestore"
import { db } from "../Firebase"
import { Link } from "react-router-dom"

export default function Service() {


  const [catedata, setcatedata] = useState([])
  useEffect(() => {

    const fatchData = () => {
      onSnapshot(collection(db, "category"), (CategoryData) => {
        // console.log("data",CategoryData.docs[0].data());
        setcatedata(
          CategoryData.docs.map((el) => {
            // return(el.data)
            return { id: el.id, ...el.data() }


          })
        )

      })
    }

    fatchData()

  }, [])

  return (
    <>
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Menu
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Menu
              </li>
            </ol>
          </nav>
        </div>
      </div>
      {/* Navbar & Hero End */}
      {/* Service Start */}
      <div className="container-xxl py-5">
        <div className="container">
          <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h5 className="section-title ff-secondary text-center text-primary fw-normal">
              Our Menus
            </h5>
            <h1 className="mb-5">Explore Our Menus</h1>
          </div>
          <div className="row g-4">
            {catedata?.map((el,index) => (
              <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s" key={index}>
                <div className="service-item rounded pt-3">
                  <div className="p-4">
                    <img src={el.image} alt="" width={"100%"} height={"150px"} />
                    <Link to={`/menuItem/${el.name}`} className="mt-3">{el.name}</Link>
                    <p>
                     {el.description} 
                    </p>
                  </div>
                </div>
              </div>
            ))}



          </div>
        </div>
      </div>
      {/* Service End */}
    </>

  )
}