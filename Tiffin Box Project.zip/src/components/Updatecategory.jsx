import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { ClipLoader } from "react-spinners"
import { toast, ToastContainer } from "react-toastify"
import { auth, db } from "../Firebase"
import { doc, onSnapshot, updateDoc } from "firebase/firestore"
import axios from "axios"

export default function Updatecategory() {
  var [Name, setName] = useState("")
  var [Image, setImage] = useState("")
  var [load, setLoad] = useState(false)
  var [url, setUrl] = useState("")
  var nav = useNavigate()
  var { id } = useParams()

  useEffect(() => {
    onSnapshot(doc(db, "category", id), (catedata) => {
      var data = catedata.data()
      setName(data.name)
      setUrl(data.image)
    })
  }, [id])

  function handleform(e) {
    e.preventDefault()

    setLoad(true)

    if (Image) {
      let data = new FormData()
      data.append("file", Image)
      data.append("upload_preset", "annpan")
      axios.post("https://api.cloudinary.com/v1_1/dqldac5ij/image/upload", data)
        .then((res) => {
          setUrl(res.data.secure_url)
        })
        .catch((err) => {
          toast.error("Image upload failed")
        })
    } else {
      savedata(url)
    }
  }

  const savedata = async (URL) => {
    let data = {
      name: Name,
      image: URL,
      status: true,
      // createdAt: Timestamp.now()  // removed to keep original
    }

    await updateDoc(doc(db, "category", id), data)
      .then(() => {
        setName("")
        toast.success("Data updated successfully!!")
        setTimeout(() => {
          nav("/admin/managecategory")
        }, 500);
      })
      .catch((err) => {
        toast.error(err.message)
      })
  }

  useEffect(() => {
    if (!!url && Image) {
      savedata(url)
    }
  }, [url])

  return (
    <>
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Add Category
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">Home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Add Category
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div className="container-fluid py-5">
        <div className="container">
          <ToastContainer />
          <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
          <div className="row ">
            {
              !load ?
                <div className="offset-md-2 col-md-8 shadow p-4 ">
                  <form onSubmit={handleform}>
                    <label htmlFor="" className="form-label">Name</label>
                    <input type="text" className="form-control" value={Name} onChange={(e) => { setName(e.target.value) }} required/>

                    <label htmlFor="" className="form-label">Old Image </label> <br />
                    <img src={url} width={"150"} alt="old" />

                    <br /><label htmlFor="" className="form-label">Image</label>
                    <input type="file" className="form-control" onChange={(e) => { setImage(e.target.files[0]) }} />

                    <button type="submit" className="btn btn-primary mt-5">update</button>
                  </form>
                </div>
                : ""
            }
          </div>
        </div>
      </div>
    </>
  )
}
