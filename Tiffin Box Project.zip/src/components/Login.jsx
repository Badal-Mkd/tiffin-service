import { useEffect, useState } from "react"
import { toast, ToastContainer } from "react-toastify"
import { ClipLoader } from "react-spinners"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { signInWithEmailAndPassword } from "firebase/auth"
import { doc, getDoc } from "firebase/firestore"
import { auth, db } from "../Firebase"

export default function Login() {
  var [email, setemail] = useState("")
  var [password, setpass] = useState("")
  var [load, setLoad] = useState(false)
  var [type, settype] = useState("password")
  var nav = useNavigate()
  var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/;

  const location = useLocation();

  useEffect(() => {
    if (location.state?.msg) {
      // show the message passed from SendBooking (or anywhere else)
      toast.error(location.state.msg, { position: "top-right" });

      // optionally clear the state from history so message doesn't reappear on back/refresh
      // replace current entry with same pathname but no state
      nav(location.pathname, { replace: true, state: {} });
    }
  }, [location, nav]);


  function checkemail(e) {
    console.log("change email fun call", e.target.value);
    setemail(e.target.value)
    //          if (emailRegex.test(email)) {
    //           console.log(email)
    // } else {
    //   toast.error("invaild email")
    // }
  }
  function handleform(e) {
    e.preventDefault()
    setLoad(true)
    signInWithEmailAndPassword(auth, email, password)
      .then(async (userdata) => {
        const docRef = doc(db, "users", userdata.user.uid)
        const docSnap = await getDoc(docRef)

        if (docSnap.exists()) {
          let data = docSnap.data()

          // ✅ check if user is blocked
          if (data.status === false) {
            setLoad(false)
            toast.error("You are blocked by admin!")
            return
          }

          //store the data
          sessionStorage.setItem("userId", userdata.user.uid)
          sessionStorage.setItem("isLogin", true)
          sessionStorage.setItem("email", email)
          sessionStorage.setItem("name", data.name)
          sessionStorage.setItem("userType", data.userType)

          toast.success("Login successfully!!")
          if (data.userType == 1) {
            setTimeout(() => {
              setLoad(false)
              nav("/admin")
            }, 2000)
          } else {
            setTimeout(() => {
              setLoad(false)
              nav("/")
            }, 2000)

            setTimeout(() => {
              window.location.reload()

            }, 2090);
          }
        } else {
          toast.error("User not found!!")
          setLoad(false)
        }
      })
      .catch((err) => {
        console.log(err)
        setLoad(false)
        toast.error(err.message)
      })
  }


  return (
    <>
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        {/* <div className="container text-center my-5 pt-5 pb-4"> */}
        <ToastContainer />
        {/* <h1 className="display-3 text-white mb-3 animated slideInDown">
        Register
      </h1>
      <nav aria-label="breadcrumb">
        <ol className="breadcrumb justify-content-center text-uppercase">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Pages</a>
          </li>
          <li className="breadcrumb-item text-white active" aria-current="page">
            Register
          </li>
        </ol> */}
        {/* </nav> */}
        {/* </div> */}
      </div>
      {/* Navbar & Hero End */}
      {/* Reservation Start */}
      <div className="container-xxl py-5 px-0 wow fadeInUp" data-wow-delay="0.1s">
        <ClipLoader size={150} cssOverride={{ marginLeft: "40%" }} loading={load} />
        {!load ?
          <div className="row g-0">
            <div className="col-md-6 ">
              <div >
                <img className=" w-100 h-100" src="assets/img/login.jpg" alt="" />
              </div>
            </div>
            <div className="col-md-6  d-flex align-items-center">
              <div className="p-5 wow fadeInUp text-center" data-wow-delay="0.2s">
                <h1 className="section-title ff-secondary  text-primary fw-normal mb-5">
                  Welcome Back
                </h1>
                <h4 className="text-black mb-4">Please enter your details</h4>
                <form onSubmit={handleform}>
                  <div className="row g-3">
                    {/* <div className="col-md-12">
                <div className="form-floating">
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    placeholder="Your Name"
                    value={name} onChange={(e)=>{setname(e.target.value)}}
                    required
                  />
                  <label htmlFor="name">Your Name</label>
                </div>
              </div> */}
                    <div className="col-md-12">
                      <div className="form-floating">
                        <input
                          type="email"
                          className="form-control"
                          id="email"
                          placeholder="Your Email"
                          value={email} onChange={checkemail}
                          required
                        />
                        <label htmlFor="email">Your Email</label>
                      </div>
                    </div>
                    <div className="col-md-12 ">

                      <div
                        className="form-floating input-group"
                        id="date3"
                        data-target-input="nearest"

                      >
                        <input
                          type={type}
                          className="form-control "
                          placeholder="Password"
                          value={password} onChange={(e) => { setpass(e.target.value) }}
                          required

                        />


                        <label htmlFor="datetime">Password</label>

                        <span className="input-group-text" onClick={() => settype(type === 'password' ? 'text' : 'password')}>
                          <i className={type === 'password' ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye'}></i>
                        </span>


                      </div>
                    </div>
                    {/*<div className="col-md-12 d-flex">
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" value="" required />
                        <label className="form-check-label " >
                          keep me loggin
                        </label>
                      </div>
                    </div>
                    <div className="col-12">
                <div className="form-floating">
                  <textarea
                    className="form-control"
                    placeholder="Special Request"
                    id="message"
                    style={{ height: 100 }}
                    defaultValue={""}
                  />
                  <label htmlFor="message">Special Request</label>
                </div>
              </div> */}
                    <div className="col-12">
                      <button className="btn btn-primary w-100 py-3" type="submit">
                        Log In
                      </button>
                    </div>
                    <div>
                      <span>
                        Don't have an account?
                        <Link to="/register"> Register</Link>
                      </span>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          : ""}
      </div>
      {/* <div
    className="modal fade"
    id="videoModal"
    tabIndex={-1}
    aria-labelledby="exampleModalLabel"
    aria-hidden="true"
  >
    <div className="modal-dialog">
      <div className="modal-content rounded-0">
        <div className="modal-header">
          <h5 className="modal-title" id="exampleModalLabel">
            Youtube Video
          </h5>
          <button
            type="button"
            className="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          />
        </div>
        <div className="modal-body">
          {/* 16:9 aspect ratio */}
      {/* <div className="ratio ratio-16x9">
            <iframe
              className="embed-responsive-item"
              src=""
              id="video"
              allowFullScreen=""
              allowscriptaccess="always"
              allow="autoplay"
            />
          </div>
        </div>
      </div>
    </div>
  </div> */}

    </>

  )
}