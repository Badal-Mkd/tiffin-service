import { Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import React, { useEffect, useState } from "react";
import { db } from "../Firebase"; // adjust path to your firebase.js
import { collection, getDocs } from "firebase/firestore";

export default function Adminhome() {
  const [counts, setCounts] = useState({
    category: 0,
    menu: 0,
    users: 0,
  });

  useEffect(() => {
    // Fetch counts for each collection
    const fetchCounts = async () => {
      const newCounts = { category: 0, menu: 0, users: 0 };

      getDocs(collection(db, "category"))
        .then((snapshot) => {
          newCounts.category = snapshot.size || 0;
          return getDocs(collection(db, "menu"));
        })
        .then((snapshot) => {
          newCounts.menu = snapshot.size || 0;
          return getDocs(collection(db, "users"));
        })
        .then((snapshot) => {
          newCounts.users = snapshot.size || 0;
          setCounts(newCounts);
        })
        .catch((err) => {
          console.error("Error fetching counts:", err);
        });
    };

    fetchCounts();
  }, []);
  return (
    <>
      <ToastContainer />
      {/* <p>{catedata[0].id}</p> */}
      <div className="container-fluid py-5 bg-dark hero-header mb-5">
        <div className="container text-center my-5 pt-5 pb-4">
          <h1 className="display-3 text-white mb-3 animated slideInDown">
            Admin Dashboard
          </h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center text-uppercase">
              <li className="breadcrumb-item">
                <a href="#">home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Admin</a>
              </li>
              <li className="breadcrumb-item text-white active" aria-current="page">
                Dashboard
              </li>
            </ol>
          </nav>
        </div>
      </div>



      <div className="container mt-5">
        <div className="row">
          {/* Category Card */}
          <div className="col-md-4">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">Total Categories</h5>
                <p className="card-text display-6">{counts.category}</p>
              </div>
            </div>
          </div>

          {/* Menu Card */}
          <div className="col-md-4">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">Total Menus</h5>
                <p className="card-text display-6">{counts.menu}</p>
              </div>
            </div>
          </div>

          {/* Users Card */}
          <div className="col-md-4">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">Total Users</h5>
                <p className="card-text display-6">{counts.users}</p>
              </div>
            </div>
          </div>
        </div>
      </div>





    </>

  )
}

